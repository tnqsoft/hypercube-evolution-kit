                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1975439
2020 LCD Display Mount by henryarnold is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This movable hinged bracket allows the LCD display to be mounted on a vertical 2020 extrusion. The display may lay flat within the frame or be moved out at up to a 90 degree angle. The joint is strong and easy to move. It uses a 35 mm x 6 mm Phillips or cap head screw, a couple of 6 mm washers, and a 6 mm Nyloc nut. Place two washers between the two parts of the hinge to make the hinge move smoothly. The display mounts to the back plate using existing holes and two 15 mm x 3 mm screws. The whole display mounts to the 2020 extrusion using 5 mm x 8 mm button head screws and extrusion fasteners.

Be sure to print with at least 50% infill. This joint has a fair amount of stress on it.

This is my HyperCube Printer where I used this display mount:
http://www.thingiverse.com/make:272257